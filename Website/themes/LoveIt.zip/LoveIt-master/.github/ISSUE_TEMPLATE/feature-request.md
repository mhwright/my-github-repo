---
name: Feature request 功能请求
about: Suggest an idea for this project 为这个项目提供一个建议
title: "[FEATURE] Some feature"
labels: enhancement
assignees: dillonzq

---

### Describe the feature you want 描述你的功能需求

- Feature 1 功能需求 1
  I want this feature to solve ... 我希望这个功能解决 ...
- Feature 2 功能需求 2
  I want this feature to solve ... 我希望这个功能解决 ...
- ...

### Useful reference 有价值的参考

If available, provide useful links to fulfill the feature.
如果可以的话, 提供实现这个功能的相关参考链接.
